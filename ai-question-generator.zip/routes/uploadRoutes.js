
const express = require("express");
const router = express.Router();
const upload = require("../middleware/uploadMiddleware");
const { handleUpload } = require("../controllers/uploadController");

router.post("/", upload.array("files"), handleUpload);

module.exports = router;
