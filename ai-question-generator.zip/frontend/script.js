
async function generate(){

document.getElementById("loading").style.display="block";

const files=document.getElementById("files").files;
const pages=document.getElementById("pages").value;

const form=new FormData();
for(let f of files){form.append("files",f);}

const upload=await fetch("/api/upload",{method:"POST",body:form});
const data=await upload.json();

const res=await fetch("/api/questions",{
 method:"POST",
 headers:{"Content-Type":"application/json"},
 body:JSON.stringify({text:data.text,pages})
});

const q=await res.json();

document.getElementById("loading").style.display="none";

document.getElementById("output").textContent=q.questions;

const link=document.getElementById("download");
link.href=q.pdf;
link.textContent="Download PDF";

}
