
const PDFDocument=require("pdfkit");
const fs=require("fs");

exports.createPDF=async(questions)=>{
 const path="uploads/papers/paper-"+Date.now()+".pdf";
 const doc=new PDFDocument();
 doc.pipe(fs.createWriteStream(path));
 doc.fontSize(20).text("AI Generated Question Paper",{align:"center"});
 doc.moveDown();
 doc.fontSize(12).text(questions);
 doc.end();
 return path;
};
