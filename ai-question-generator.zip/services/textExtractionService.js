
const fs=require("fs");
const pdf=require("pdf-parse");
const mammoth=require("mammoth");
const Tesseract=require("tesseract.js");

exports.extractText=async(filePath)=>{

 if(filePath.endsWith(".txt")){
  return fs.readFileSync(filePath,"utf8");
 }

 if(filePath.endsWith(".pdf")){
  const data=await pdf(fs.readFileSync(filePath));
  return data.text;
 }

 if(filePath.endsWith(".docx")){
  const result=await mammoth.extractRawText({path:filePath});
  return result.value;
 }

 if(filePath.endsWith(".png")||filePath.endsWith(".jpg")){
  const {data:{text}}=await Tesseract.recognize(filePath,"eng");
  return text;
 }

 return "";
};
