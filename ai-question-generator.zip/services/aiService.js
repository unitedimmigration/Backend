
const OpenAI = require("openai");

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

exports.generateAIQuestions = async (text,pages)=>{

  const map={1:8,2:15,3:20,4:25,5:30};
  const count=map[pages]||10;

  const prompt=`Generate ${count} exam questions from this material:

${text}

Divide into:
SECTION A – MCQ
SECTION B – True/False
SECTION C – Assertion Reason
SECTION D – Short Answer
SECTION E – Long Answer
SECTION F – Case Study
`;

  const completion = await client.chat.completions.create({
    model:"gpt-4o-mini",
    messages:[{role:"user",content:prompt}]
  });

  return completion.choices[0].message.content;
};
