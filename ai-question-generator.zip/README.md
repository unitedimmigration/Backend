
# AI Question Paper Generator

Upload study material and generate exam papers using AI.

Run locally:
npm install
node server.js
