
const { extractText } = require("../services/textExtractionService");

exports.handleUpload = async (req,res)=>{
  try{
    let combinedText = "";
    for(const file of req.files){
      const text = await extractText(file.path);
      combinedText += text + "\n";
    }
    res.json({text:combinedText});
  }catch(e){
    res.status(500).json({error:e.message});
  }
};
