
const { generateAIQuestions } = require("../services/aiService");
const { createPDF } = require("../services/pdfService");

exports.generateQuestions = async (req,res)=>{
  try{
    const { text,pages } = req.body;
    const questions = await generateAIQuestions(text,pages);
    const pdf = await createPDF(questions);
    res.json({questions,pdf});
  }catch(e){
    res.status(500).json({error:e.message});
  }
};
